## Preservation of Build — Project Checklist

- Personal-first
- Accretive semantics
- Fragment-first ingestion
- Concept-first UI
