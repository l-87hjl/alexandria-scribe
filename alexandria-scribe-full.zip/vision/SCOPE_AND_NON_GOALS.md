## Scope

- Semantic preservation of ideas over time
- Concept emergence without manual categorization
- Support for prose, humor, code, and precision

## Non-Goals

- Task management
- Manual tagging workflows
- Premature ontology enforcement
- Document-centric organization
