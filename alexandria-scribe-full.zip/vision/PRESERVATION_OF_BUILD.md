## Preservation of Build

Humans repeat themselves.
Sometimes nothing new is added.
Sometimes one phrasing changes everything.

Redundancy is tolerated.
Novelty inside repetition is detected.
Ideas are never overwritten.

Meaning is allowed to accrete.
