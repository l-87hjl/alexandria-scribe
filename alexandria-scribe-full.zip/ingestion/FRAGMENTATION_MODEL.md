## Fragmentation Model

Fragment first.
Judge later.
Over-inclusion is intentional.
