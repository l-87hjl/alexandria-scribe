## Ingestion Phases

Phase 1: Plain text
Phase 2: Documents (PDF)
Phase 3: Conversations
