## Logging Schema

Append-only operational events.
No semantic fields.
