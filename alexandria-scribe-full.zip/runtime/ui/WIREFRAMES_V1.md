## UI Wireframes (V1)

Concept list → Concept view → Synthesis actions.
No folders. No tags.
