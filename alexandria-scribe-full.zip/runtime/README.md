## Runtime Layer

Executable code implementing the architecture.
No semantic logic lives here.
