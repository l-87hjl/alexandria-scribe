## V1 UI Flow

Users begin with concepts, not files.

They observe what has emerged.
They do not organize.
