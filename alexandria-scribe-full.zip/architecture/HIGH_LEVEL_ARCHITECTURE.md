## High-Level Architecture

1. Ingestion & Decomposition
2. Semantic Memory (Accretion)
3. Human Interface & Synthesis

Documents are containers.
Fragments are atomic.
Concepts evolve.
Nothing is deleted.
