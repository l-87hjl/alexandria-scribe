## Data Model

Fragment: immutable atomic unit.
Concept: emergent and evolving.
Relationship: reinforces, refines, diverges.
