## Authorship Model

Single-author by default.
Authorship is never erased.
