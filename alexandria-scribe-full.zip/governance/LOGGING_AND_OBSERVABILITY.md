## Logging and Observability

Logs are operational only.
They never affect semantic state.
