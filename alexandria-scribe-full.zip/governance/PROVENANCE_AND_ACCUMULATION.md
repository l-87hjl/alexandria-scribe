## Provenance and Accumulation

Nothing is deleted.
Origins remain visible.
