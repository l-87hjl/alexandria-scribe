## Synthesis and Export

Synthesis is concept-driven.
Ambiguity is preserved.
