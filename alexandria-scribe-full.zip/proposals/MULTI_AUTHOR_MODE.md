## Multi-Author Mode (Proposal)

Preserve divergence.
No forced consensus.
