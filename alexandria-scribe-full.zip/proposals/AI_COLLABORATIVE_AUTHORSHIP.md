## AI Collaborative Authorship (Proposal)

AI may assist.
AI may not replace provenance.
